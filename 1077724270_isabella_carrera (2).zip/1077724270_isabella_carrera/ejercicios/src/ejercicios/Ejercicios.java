/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicios;

/**
 *
 * @author USER
 */
public class Ejercicios {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
                /* 
        *para definir una variabpe
        *primero el tipo de dato
        segundo el nombre de la variable
        *ejemplo 
        *int num1 
        *para asignar un valor o inicializar 
        *num1=5;
        */
        int num1=5;
        int num2=2;
        num2=8;
        int num3 = 2;
         System.out.println(num1);
         System.out.println(num2);
         System.out.println(num3);
         
         //tipos de datos 
         int num4 = 6;
         float decimal = 5.4f;
         double decimal12 =5.4;
         String nombre = "isa";
         char letra = 'p';
         boolean boleano = false ;
         short num5 = 6;
         
         /* 
         *variable de tipos de datos explisitos 
         int num5=10;
         variable de tipo de datos implicita
         var num6=5;
         
         */
         var variable = "julian";
         variable = "juan jose";
         System.out.println(variable);
         char  caracter=61;
         System.out.println(caracter);
          // concatenar
          int edad=31;
          System.out.println("hola"+"soy"+nombre+" tengo "+edad+"años");
          System.out.println("el resultado es:"+(5+3));
          System.out.println("el resultado es:"+(10*2));
          System.out.println("el resultado es:"+(23/2));
          System.out.println("el resultado es:"+(2-1));
         //1
        double celsius = 20;
        double fahrenheit = (celsius * 9/5) + 32;
        double kelvin = celsius + 273;
        System.out.println("Celsius: " + celsius);
        System.out.println("Fahrenheit: " + fahrenheit);
        System.out.println("Kelvin: " + kelvin);
        //2
        double peso = 99.95;
        double altura = 1.69;
        double alturaMetros = altura / 100;
        
        double imc = peso / (alturaMetros * alturaMetros);

        System.out.println("Peso: " + peso + " kg");
        System.out.println("Altura: " + alturaMetros + " m");
        System.out.println("Tu indice de Masa Corporal es: " + imc);
        
        //3
        double base = 10;
        double altura2 = 5;
        double lado1 = 8;
        double lado2 = 4;
        
        double area = (base * altura) / 2;
        double perimetro = base + lado1 + lado2;
        
        System.out.println("Base: " + base);
        System.out.println("Altura2: " + altura2);
        System.out.println("Lado1: " + lado1);
        System.out.println("Lado2: " + lado2);
        System.out.println("Area: " + area);
        System.out.println("Perimetro: " + perimetro);
        
        //4
        int num6 = 4;
        int num7 = 2;
        
        System.out.println("el resultado es:"+(4+2));
        System.out.println("el resultado es:"+(4-2));
        System.out.println("el resultado es:"+(4/2));
        System.out.println("el resultado es:"+(4*2));
        System.out.println("el resultado es:"+(5%4));
        
        //5
        
        int numero1 = 3;
        int numero2 =10;
       
        numero1 = numero1 + numero2;
        numero2 = numero1 - numero2;
        numero1 = numero1 - numero2;
        System.out.println("Numero1:"+ numero1 );
        System.out.println("Numero2:" + numero2);
        
        //6
        
        int numero = -5;
        if (numero > 0) {
           System.out.println("el numero es positivo"); 
       }  else if (numero < 0) {
           System.out.println("el numero es negativo");
       }  else {
           System.out.println("el numero es cero");
       }
        
        //7
        
       int numer1 = 18;
       int numer2 = 15;
       int numer3 = 6;
       
       int mayor;
       if (numer1 >= numer2 && numer1 >= numer3) {
           mayor = numer1;
       } else if (numer2 >= numer1 && numer2 >= numer3) {
            mayor = numer2;
        } else {
            mayor = numer3;
        }
        System.out.println("El numero mayor es: " + mayor);
        
        //8
        
         int anio = 2024; 

        if ((anio % 4 == 0 && anio % 100 != 0) || (anio % 400 == 0)) {
            System.out.println("El año " + anio + " es bisiesto.");
        } else {
            System.out.println("El año " + anio + " no es bisiesto.");
        }
        
        //9
        
        double nume1 = 3;
        double nume2 = 5; 
        char operacion = '+'; 

        double resultado;

        switch (operacion) {
            case '+':
                resultado = nume1 + nume2;
                System.out.println("Resultado: " + resultado);
                break;
            case '-':
                resultado = nume1 - nume2;
                System.out.println("Resultado: " + resultado);
                break;
            case '*':
                resultado = nume1 * nume2;
                System.out.println("Resultado: " + resultado);
                break;
            case '/':
                if (nume2 != 0) {
                    resultado = nume1 / nume2;
                    System.out.println("Resultado: " + resultado);
                } else {
                    System.out.println("Error: Division por cero.");
                }
                break;
            default:
                System.out.println("Operación no valida.");
        }
        //10 
        
        int lados1 = 7; 
        int lados2 = 3; 
        int lados3 = 2; 

        if (lados1 == lados2 && lados2 == lados3) {
            System.out.println("El triangulo es equilátero.");
        } else if (lados1 == lados2 || lados1 == lados3 || lados2 == lados3) {
            System.out.println("El triangulo es isósceles.");
        } else {
            System.out.println("El triangulo es escaleno.");
        }
        
        //11 
           int nu1 = 2; 

        System.out.println("Tabla de multiplicar del " + nu1);
        for (int i = 1; i <= 10; i++) {
            System.out.println(nu1 + " x " + i + " = " + (nu1 * i));
        }
        
        //12
          int N = 4; 
        int suma = 0;
        int i = 1;

        while (i <= N) {
            suma += i;
            i++;
        }

        System.out.println("La suma de los primeros " + N + " numeros es: " + suma);
        
        //13 
        
        int N2 = 1234; 
        int contador = 0;

        do {
            N2 /= 10; 
            contador++;
        } while (N2 != 0);

        System.out.println("El numero tiene " + contador + " digitos.");
        
        //14
        
        
       
       }
    }
    

